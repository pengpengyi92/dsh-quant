import assert from 'node:assert/strict'
import { after, afterEach } from 'node:test'

const nativeFetch = globalThis.fetch
let attempts = 0
let restored = 0
const denyNetwork = async () => {
  attempts++
  throw new Error('Review guard: an unmocked fetch must never run')
}
globalThis.fetch = denyNetwork
afterEach(() => {
  assert.equal(globalThis.fetch, denyNetwork, 'fetch was not restored after a test')
  restored++
})
after(() => {
  globalThis.fetch = nativeFetch
  assert.equal(attempts, 0)
  assert.equal(restored, 16)
  console.log(JSON.stringify({ fetch_restored_after_each: restored, unmocked_fetch_attempts: attempts }))
})
await import('../tests/market-fetch.spec.ts')
